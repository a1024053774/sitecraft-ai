# 中小企业 AI 建站：资源调研与接入草案

调研日期：2026-09-15

## 结论

建议保留“Skill + 模板 + 提示词”的方向，但补上行业简报、明确授权的资源池、设计 token、按条件选择区块以及真实截图审查。
第一步接入现有系统，不默认迁移技术栈，也不先构建复杂多代理平台。

初步选型：UI UX Pro Max 负责行业/风格候选；Impeccable 作为审美主流程；Marketing Skills 负责有事实依据的文案；Vercel 指南和真实浏览器负责验收。Anthropic frontend-design 与 Taste Skill 用于替代对照，而非全部叠加。
这些角色分工是本次设计建议，不是实测优胜结论。第三方资源依据见 resources.json 中的 official_urls。

整站可先考察 AstroWind / Astroplate；React 组件体系可先考察 shadcn/ui + Tailark OSS；HTML/Tailwind 区块可先考察 HyperUI。它们不是同一个技术栈，不应未经适配混装。
传统行业设计可参考 CodeStitch / Lexington，但生成器/平台用途须遵守专门许可。

## 包内内容

- resources.json：30 个官方资源与规范入口，包含建议场景、许可观察和限制；所有条目默认未获生产批准。
- industry-blueprints.json：8 个原创行业结构草案，不是可运行模板。
- skills/smb-site-orchestrator/SKILL.md：原创建站编排 Skill 草案，不附执行器。
- prompts/design-reviewer.md：独立截图审查提示词。
- examples/template-manifest.example.json：一个拟建工业模板的元数据示例，状态为未实现。
- evaluation-plan.md：24 份首轮结果的对照实验设计与发布门槛。
- LICENSE-REVIEW.md：授权审核注意事项。

## 使用步骤

先核对现有项目技术栈和交付模型。选一个主 Skill 与两个至三个匹配底座，在隔离分支固定版本试装。
以当前内置模板为 A 组保留基线。把选中的组件映射为实际 section ID，再让 page-plan 只引用白名单 ID。
补齐客户事实、素材、表单测试收件端与浏览器工具后，才执行实验；不要把本资料包的存在当成项目已经接通。

## 证据边界

本次查阅公开官方仓库、文档和许可页，没有读取用户项目代码，没有安装/运行外部 Skill、模板、安装器或浏览器，没有实际测出视觉、性能、成本或转化收益。
本包不含第三方模板源码、付费素材、字体文件、API 密钥或真实客户个人资料。未实际执行多代理调研；包内多角色流程仅是后续实施建议。
资源链接与许可可能变化，采用前应重新核对所选版本；所列代码的许可证不自动覆盖演示图片和商标。
