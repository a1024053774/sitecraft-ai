# 授权审核与生产准入

本文件是工程选型风险梳理，不替代对具体合同与版本的法律审核。

## 先确认交付模型

“内部用 AI 辅助做客户定制站”与“用户在产品里选择素材并自动生成/导出网站”不是同一用法。
客户能否选模板、导出源码、再次复制、把网站当模板复用，以及素材是否暴露给第三方模型服务，都应明确写进授权询问。

## 本次需要特别注意的资源

Shadcnblocks 明确限制网站生成器与相关 AI 生成器。出处：`https://www.shadcnblocks.com/license`。
CodeStitch 禁止以其模板构建重新打包并分发/转售给第三方的平台、工具或服务。出处：`https://codestitch.app/terms-of-service`。
Lexington 标准许可不覆盖模板嵌入 builders / generators 或可导出、复用模板的平台；提供扩展许可咨询。出处：`https://lexingtonthemes.com/legal/license` 与 `https://lexingtonthemes.com/legal/extended-licensing`。AI-ready 不代表无条件允许 AI-agent 账户访问其私有仓库，必须遵守账号与集成限制。
Tailwind Plus 的当前许可页在本次访问中跳转登录，不能据此确认平台权利。出处入口：`https://tailwindcss.com/plus/license`。
Cruip Simple Light 的 README 同时标 GPL 和不许重发布/分发/转售，不在本轮直接判定可内置。出处：`https://github.com/cruip/tailwind-landing-page-template`。
Astroplate 的代码 MIT 与演示图片授权分开。出处：`https://github.com/zeon-studio/astroplate`。

## 每个准备进入生产的条目必须补齐

官方来源、固定 commit/tag、许可证原文与复核时间、所用文件清单、版权声明、第三方依赖与素材许可。
商业资源另存购买主体、席位数、发票/合同、生成器/平台使用是否书面获准及终止后权利。
图片保存原始来源、许可、作者、用途、人物/商标等限制与客户确认状态。客户上传也不自动等于客户拥有全部权利。
第三方 Skill 的脚本、hooks、下载器、网络目的地和权限单独审查；本包不执行这些脚本。

审核通过后由明确负责人更改 production_approved；不要让模型因 README 写着 free、AI-ready 或 commercial use 就自动放行。
